
sudo su komutu ile root olalım

./isoyap

MASAÜSTÜ VE KURULUM KOMUTLARI

Xfce       : apt-get install xfce4 xfce4-goodies network-manager-gnome
Lxde       : apt-get install lxde network-manager-gnome
Cinnamon   : apt-get install cinnamon
KDE plasma : apt-get install kde-standard
Gnome      : apt-get install gnome-core
Mate       : apt-get install lightdm mate-desktop-environment-extras network-manager-gnome

PARDUS XFCE İÇİN KURULACAK PAKETLER:

apt-get install pardus-about pardus-backgrounds pardus-common-desktop pardus-configure pardus-dolunay-grub-theme pardus-gtk-theme pardus-icon-theme pardus-image-writer pardus-locales pardus-package-installer pardus-power-manager pardus-software pardus-usb-formatter pardus-welcome pardus-xfce-settings pardus-installer blueman gnome-calculator gvfs-backends neofetch synaptic rar

Yazıcı ve tarayıcı paketleri kurmak için: apt-get install system-config-printer cups xsane

apt-get remove xterm firefox-esr icedtea-netx -y
sources.list boşluk at ve usr/share/applications dizininde xfburn.desktop dosyasını sil

apt update 
apt upgrade
update-grub

exit

./isoolustur



Unuttuğumuz yada daha sonra ilave etmek istediğimiz bir şey varsa:

for i in dev dev/pts proc sys; do mount -o bind /$i pardus-chroot/$i; done
chroot pardus-chroot /bin/bash



PARDUS KDE CİNNAMON LXDE MATE İÇİN KURULACAK PAKETLER:

apt-get install pardus-about pardus-backgrounds pardus-dolunay-grub-theme pardus-image-writer pardus-package-installer pardus-software pardus-usb-formatter pardus-installer blueman gvfs-backends synaptic neofetch

sudo apt install xterm

Pardus kurucu aracı (live-installler) canlıda masaüstünde çalışmayacaktır bu sebeple Xfce dışındaki masaüstü ortamlarında chroot içindeki /usr/share/applications/live-installer.desktop da değişiklik yapmak lazım

#The path to the folder in which the executable is run kısmını
Path=/lib/live-installer/
#The executable of the application, possibly with arguments kısmını
Exec=live-installer
olarak değiştirmek yeterli





SÜRÜM NOTLARI:

Pardus 21.1 resmi olmayan Kişisel Xfce Lite 64 Bit sürümüdür.
Pardus depolarına ilaveten Backports depo eklenmiştir.
Linux Kernel 5.15 
Libre Office, Gimp, java, VLC, Posta istemcileri, Browser, Yazıcı ve Tarayıcı paketleri yoktur.
Galculator yerine gnome-calculator, file-roller yerine de xarchivers kurulu gelir.
10/03/2022 de oluşturulmuştur.
Yazıcı ve tarayıcı ile işiniz varsa: sudo apt install system-config-printer cups xsane





