 #!/bin/bash
 #bu scprit sudo ./debyap.sh ile çalışır
 apt update
 apt install devscripts equivs -y
 mk-build-deps --install
 debuild -us -uc -b
 mkdir -p /output/
 mv ../*.deb /output/
 mv ./*.deb /output/
