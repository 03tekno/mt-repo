# Muslim Linux nosystemd - made by teaiso
Muslim Linux iso build profile
