#!/usr/bin/env bash
#chroot airootfs mkinitcpio -p linux
echo "Nothing to do!"
