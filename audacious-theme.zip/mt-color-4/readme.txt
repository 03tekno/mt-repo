This Skin was partial generated using SkinAmp. Skinamp is freeware, you can download it on my homepage!

http://members.tripod.de/DrAlgebra/english
My email: Dr.Algebra@gmx.de

P.S.: I'm NOT the author of this skin!!!

Thank you for reading,
      Dr. Algebra.

Date: 12 Nis, 2022
