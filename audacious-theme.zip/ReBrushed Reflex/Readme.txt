This theme is made for audacious its rebrushed Reflex Theme for AIMP music player in Windows
made by: Dragoslav Rakic
drakic2@gmail.com
